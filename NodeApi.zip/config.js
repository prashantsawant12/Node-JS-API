module.exports = {
    url: 'mongodb+srv://e-comuser:e-compass@e-com-wisuz.mongodb.net/test?retryWrites=true&w=majority',
    serverport: 3000 
}